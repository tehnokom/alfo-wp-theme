document.createElement('section');
document.createElement('header');
document.createElement('footer');
document.createElement('nav');
document.createElement('aside');
document.createElement('article');
document.createElement('mark');