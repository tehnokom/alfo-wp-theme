					</div>

				</div>

			</div>
		</div>
	</div>
	
	<!-- Футер
	=========================================================== -->
	<footer class="l_footer">
	<br />	
	</footer>
	
</div>
<?php wp_footer(); ?>

</body>
</html>